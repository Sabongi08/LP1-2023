package interfacee;

public interface Comercializante {
    public void comercializa();
}
