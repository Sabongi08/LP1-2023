package model;

public class Empresa {
}
