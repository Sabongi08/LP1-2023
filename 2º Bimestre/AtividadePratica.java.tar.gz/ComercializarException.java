package exception;

public class ComercializarException {
}
