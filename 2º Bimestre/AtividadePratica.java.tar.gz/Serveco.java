package model;

public class Serveco {
    private boolean disponivel;

    public Serveco(boolean disponivel) {
        this.disponivel = disponivel;
    }


}
