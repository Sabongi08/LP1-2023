package entity;

import jakarta.persistence.*;

@Entity (name = "endereco")
@Table (name = "endereco")

public class Endereco {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private String Cidade;

    @Column
    private String rua;



    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String cidade) {
        Cidade = cidade;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public Endereco(String cidade, String rua) {
        Cidade = cidade;
        this.rua = rua;
    }





    @Override
    public String toString() {
        return "Endereco{" +
                "id=" + id +
                ", Cidade='" + Cidade + '\'' +
                ", rua='" + rua + '\'' +
                '}';
    }
}
