package gaeeds.projeto.entity;
import jakarta.persistence.*;

@Table
public class Main {

}


